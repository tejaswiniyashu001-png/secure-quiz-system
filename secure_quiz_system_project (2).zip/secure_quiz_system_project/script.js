
function login(){

let user=document.getElementById("username").value;
let pass=document.getElementById("password").value;

if(user=="student" && pass=="1234"){
localStorage.setItem("user",user);
window.location="quiz.html";
}else{
document.getElementById("msg").innerText="Invalid Login";
}
}

function submitQuiz(){

let score=0;

let q1=document.querySelector('input[name="q1"]:checked');
let q2=document.querySelector('input[name="q2"]:checked');
let q3=document.querySelector('input[name="q3"]:checked');
let q4=document.querySelector('input[name="q4"]:checked');
let q5=document.querySelector('input[name="q5"]:checked');

if(q1 && q1.value=="a") score++;
if(q2 && q2.value=="c") score++;
if(q3 && q3.value=="a") score++;
if(q4 && q4.value=="b") score++;
if(q5 && q5.value=="b") score++;

localStorage.setItem("score",score);
window.location="result.html";
}

if(document.getElementById("score")){
let score=localStorage.getItem("score");
document.getElementById("score").innerText="Score: "+score+" / 5";
}

function logout(){
localStorage.clear();
window.location="login.html";
}
